import asyncio
from playwright import async_api
from playwright.async_api import expect

async def run_test():
    pw = None
    browser = None
    context = None
    
    try:
        # Start a Playwright session in asynchronous mode
        pw = await async_api.async_playwright().start()
        
        # Launch a Chromium browser in headless mode with custom arguments
        browser = await pw.chromium.launch(
            headless=True,
            args=[
                "--window-size=1280,720",         # Set the browser window size
                "--disable-dev-shm-usage",        # Avoid using /dev/shm which can cause issues in containers
                "--ipc=host",                     # Use host-level IPC for better stability
                "--single-process"                # Run the browser in a single process mode
            ],
        )
        
        # Create a new browser context (like an incognito window)
        context = await browser.new_context()
        context.set_default_timeout(5000)
        
        # Open a new page in the browser context
        page = await context.new_page()
        
        # Navigate to your target URL and wait until the network request is committed
        await page.goto("http://localhost:62507", wait_until="commit", timeout=10000)
        
        # Wait for the main page to reach DOMContentLoaded state (optional for stability)
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=3000)
        except async_api.Error:
            pass
        
        # Iterate through all iframes and wait for them to load as well
        for frame in page.frames:
            try:
                await frame.wait_for_load_state("domcontentloaded", timeout=3000)
            except async_api.Error:
                pass
        
        # Interact with the page elements to simulate user flow
        # -> Click on the product customization page link to navigate there.
        frame = context.pages[-1]
        # Click on 'จัดยาดมเอง' (Customize product) link to go to product customization page
        elem = frame.locator('xpath=html/body/form/header/nav/div/div/ul/li[3]/a').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        # -> Select all available customization options (checkboxes) for the product.
        frame = context.pages[-1]
        # Select checkbox for Eucalyptus
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Peppermint
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[2]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Lavender
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[3]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Lemongrass
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[4]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Citrus
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[5]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Bergamot
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[6]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Rosemary
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[7]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Kaffir Lime
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[14]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        frame = context.pages[-1]
        # Select checkbox for Galangal
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div/div[13]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        # -> Click the submit button to add the customized product to the cart.
        frame = context.pages[-1]
        # Click the 'เพิ่มลงตะกร้า' (Add to cart) submit button to submit the customized product
        elem = frame.locator('xpath=html/body/form/div[2]/div/main/div/div/div[2]/div/div[2]/input').nth(0)
        await page.wait_for_timeout(3000); await elem.click(timeout=5000)
        

        # --> Assertions to verify final state
        frame = context.pages[-1]
        await expect(frame.locator('text=Custom Inhaler Blend').first).to_be_visible(timeout=30000)
        await expect(frame.locator('text=สูตรที่ปรุง: Eucalyptus, เปปเปอร์มินต์, Lavender, Lemongrass, Citrus, Bergamot, Rosemary, Nutmeg (Look Jun), มะกรูด').first).to_be_visible(timeout=30000)
        await expect(frame.locator('text=฿59.00').first).to_be_visible(timeout=30000)
        await asyncio.sleep(5)
    
    finally:
        if context:
            await context.close()
        if browser:
            await browser.close()
        if pw:
            await pw.stop()
            
asyncio.run(run_test())
    